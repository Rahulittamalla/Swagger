package avitepa.foundation.bank.AVITEPA_bank.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import avitepa.foundation.bank.AVITEPA_bank.model.Customer;


public interface CustomerRepo  extends JpaRepository<Customer,Long>{
	
	Optional<Customer> findByEmail(String email);
	void delete(Customer customer);
	void deleteById(Long id);

}
