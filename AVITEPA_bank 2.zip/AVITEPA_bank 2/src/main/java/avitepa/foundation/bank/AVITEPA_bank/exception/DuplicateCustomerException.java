package avitepa.foundation.bank.AVITEPA_bank.exception;

public class DuplicateCustomerException extends RuntimeException{
	
	public DuplicateCustomerException(String email)
	{
	super("Customer with email " +email+ "already exists");
	}

}
