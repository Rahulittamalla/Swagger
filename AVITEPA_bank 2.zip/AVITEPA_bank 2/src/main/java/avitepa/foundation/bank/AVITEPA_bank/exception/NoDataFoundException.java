package avitepa.foundation.bank.AVITEPA_bank.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class NoDataFoundException extends RuntimeException{
	
	public NoDataFoundException()
	{
		super("No data found for the given request");
	}

}
