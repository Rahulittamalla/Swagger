package avitepa.foundation.bank.AVITEPA_bank.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import avitepa.foundation.bank.AVITEPA_bank.exception.CustomerNotFoundException;
import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.repo.AccountRepo;
import avitepa.foundation.bank.AVITEPA_bank.repo.CustomerRepo;

@Service
public class TransferService {
	
	@Autowired
	private AccountRepo accountRepo;
	
	@Autowired
	private CustomerRepo customerRepo;
	
	public void transferFunds(Long sourceAccountId, Long targetAccountId, Double amount)
	{
		Account sourceAccount= accountRepo.findById(sourceAccountId).orElseThrow();
		
		Account targetAccount= accountRepo.findById(targetAccountId).orElseThrow();
		
		if(sourceAccount.getBalance()<amount)
		{
			throw new IllegalArgumentException("insufficient funds in source account");
		}
		
		sourceAccount.setBalance(sourceAccount.getBalance()-amount);
		
		targetAccount.setBalance(targetAccount.getBalance()+amount);
		
		accountRepo.saveAll(Arrays.asList(sourceAccount,targetAccount));
		
		
		
		
	}
	
	 
	  
	 

}
