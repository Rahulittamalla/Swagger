package avitepa.foundation.bank.AVITEPA_bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import avitepa.foundation.bank.AVITEPA_bank.exception.CustomerNotFoundException;
import avitepa.foundation.bank.AVITEPA_bank.exception.DuplicateCustomerException;
import avitepa.foundation.bank.AVITEPA_bank.exception.DuplicationAccountTypeException;
import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.repo.AccountRepo;
import avitepa.foundation.bank.AVITEPA_bank.repo.CustomerRepo;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepo customerRepo;
	
	@Autowired
	private AccountRepo accountRepo;
	
	public Customer addCustomer(Customer customer)
	{
		Optional <Customer> existingCustomer=customerRepo.findByEmail(customer.getEmail());
		if(existingCustomer.isPresent())
		{
			throw new DuplicateCustomerException(customer.getEmail());
		}
		
		customer.getAccounts().forEach(account->account.setCustomer(customer));
		return customerRepo.save(customer);
		
	}
	
	public void deleteCustomer(long id)
	{
		//Customer customer=getCustomerWithAccounts(id);
		Customer customer=customerRepo.findById(id).orElseThrow(()->new CustomerNotFoundException(id));
		customerRepo.delete(customer);
	}
	
	public Customer getCustomerWithAccounts(Long id)
	{
		return customerRepo.findById(id).orElseThrow(()->new CustomerNotFoundException(id));
	}
	
	
	public void addAccountToCustomer(Long customerId,Account account)
	{
		Customer customer2= customerRepo.findById(customerId).orElseThrow(()-> new CustomerNotFoundException(customerId));
		
		for(Account account2:customer2.getAccounts())
			
			if(account2.getAccountType().equalsIgnoreCase(account.getAccountType()))
			{
				throw new DuplicationAccountTypeException(account.getAccountType());
			}
		 account.setCustomer(customer2);
		 account.setAccountType(account.getAccountType());
		 account.setBalance(account.getBalance());
		 accountRepo.save(account);
		 
	}
	
	public List<Customer> getAllCustomer()
	{
		return customerRepo.findAll();
	}
	
	public Customer updateTheCustomerDetails(Long customerId,Customer existingCustomer)
	{
	   Customer foundCustomer=customerRepo.findById(customerId).orElseThrow(()-> new CustomerNotFoundException(customerId));
		
	    foundCustomer.setCustomerId(customerId);
		foundCustomer.setCustomerName(existingCustomer.getCustomerName());
		foundCustomer.setEmail(existingCustomer.getEmail());
		
		return customerRepo.save(foundCustomer);
		
	}

}
