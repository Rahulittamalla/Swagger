package avitepa.foundation.bank.AVITEPA_bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import avitepa.foundation.bank.AVITEPA_bank.exception.CustomerNotFoundException;
import avitepa.foundation.bank.AVITEPA_bank.exception.NoDataFoundException;
import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.service.AccountService;
import avitepa.foundation.bank.AVITEPA_bank.service.CustomerService;
import avitepa.foundation.bank.AVITEPA_bank.service.TransferService;

@RestController
@RequestMapping("/api")
public class CustomerConntroller {

	@Autowired
	private CustomerService customerService;

	//get all the customers 
	@GetMapping("/getall") 
	public ResponseEntity<List<Customer>> getAllCustomer() throws NoDataFoundException
	{
		List<Customer> list = customerService.getAllCustomer();
		if (list.isEmpty())
			throw new NoDataFoundException();
		else
			return new ResponseEntity<>(list, HttpStatus.OK);
		
		
	}

	@PutMapping("/update/{existingId}")
     public ResponseEntity<Customer> updateTheCustomerDetails(@PathVariable Long existingId,@RequestBody Customer customer) throws CustomerNotFoundException
     {
		Customer checkCustomer=customerService.updateTheCustomerDetails(existingId, customer);
		
		if(checkCustomer!=null)
		{
	 
    	 return new ResponseEntity<Customer>(checkCustomer, HttpStatus.OK);
		}
		
		else throw new CustomerNotFoundException(existingId);
      }

	@PostMapping("/save")
	public ResponseEntity<Customer> createCusomer(@RequestBody Customer customer) {

		return new ResponseEntity<Customer>(customerService.addCustomer(customer), HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Customer> deleteCustomerById(@PathVariable Long id) {
		customerService.deleteCustomer(id);

		return ResponseEntity.noContent().build();
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<Customer> getCustomer(@PathVariable Long id) {
		return new ResponseEntity<Customer>(customerService.getCustomerWithAccounts(id), HttpStatus.OK);
	}

	@PostMapping("/{customerId}/addAccount")
	public ResponseEntity<Void> addAccountToCustomer(@PathVariable Long customerId, @RequestBody Account account) {

		customerService.addAccountToCustomer(customerId, account);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	
	
	
	
}
