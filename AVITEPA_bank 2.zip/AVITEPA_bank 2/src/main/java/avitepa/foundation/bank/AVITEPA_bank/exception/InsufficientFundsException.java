package avitepa.foundation.bank.AVITEPA_bank.exception;

public class InsufficientFundsException extends RuntimeException{
	
	public InsufficientFundsException(String accountType)
	{
		super("Insufficient funds in account of type" +accountType);
	}

}
