package avitepa.foundation.bank.AVITEPA_bank.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import avitepa.foundation.bank.AVITEPA_bank.model.Account;

public interface AccountRepo extends JpaRepository<Account,Long>
{

@Modifying
@Query("DELETE FROM Account a WHERE a.id= :accountId")
void deleteById(@Param("accountId") Long accountId);

}
