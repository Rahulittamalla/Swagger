package avitepa.foundation.bank.AVITEPA_bank;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import avitepa.foundation.bank.AVITEPA_bank.controller.AccountController;
import avitepa.foundation.bank.AVITEPA_bank.service.AccountService;
import avitepa.foundation.bank.AVITEPA_bank.service.TransferService;
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class AccountControllerTest {
	
	@InjectMocks
	private AccountController accountController;
	
	@Mock
	private AccountService accountService;
	
	@Mock
	private TransferService transferService;
	
	@Test
	public void deleteByAccountId() throws Exception
	
	{
		Long accountId=1L;
		
		//ResponseEntity<Account> expectedResponse= ResponseEntity.noContent().build();
		
		//doNothing().when(accountService).deleteAccount(accountId);
		
		ResponseEntity<Void> actualResponse= accountController.deleteAccountById(accountId);
		
		//Assert
		
		verify(accountService,times(1)).deleteAccount(accountId);
		
		assertEquals(HttpStatus.NO_CONTENT,actualResponse.getStatusCode());
		
		
		//assertEquals(expectedResponse.getStatusCode(),actualResponse.getStatusCode());
		
	}
	
	@Test
	public void transferFunds_Success()
	{
		Long sourceAccountId=1L;
		
		Long targetAccountId=2L;
		
		Double amount=12345.0;
		
		//Act
		
		ResponseEntity<Void> response= accountController.transferFunds(sourceAccountId, targetAccountId, amount);
		
		verify(transferService,times(1)).transferFunds(sourceAccountId, targetAccountId, amount);
		
		assertEquals(HttpStatus.OK,response.getStatusCode());
	}

	

}
