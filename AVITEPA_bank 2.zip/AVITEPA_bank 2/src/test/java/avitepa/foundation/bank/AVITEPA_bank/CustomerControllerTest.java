package avitepa.foundation.bank.AVITEPA_bank;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import avitepa.foundation.bank.AVITEPA_bank.controller.CustomerConntroller;
import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.service.CustomerService;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class CustomerControllerTest {
	
	@InjectMocks
	private CustomerConntroller customerController;

	@Mock
	private CustomerService customerService;
	
	@Test
	public void createCustomer() throws Exception
	{
		
		//create a sample customer
		Customer customer=new Customer();
	         customer.setCustomerId(1L);
				customer.setCustomerName("peter");
				customer.setEmail("spiderman@example.com");
				
				//Create some sample accounts for the customer
				List<Account> accounts= new ArrayList<>();
				
				Account account1 =new Account();
				account1.setAccountId(1L);
				account1.setAccountType("Savings");
				account1.setBalance(100000);
				account1.setCustomer(customer);
			
				
				Account account2= new Account();
				account2.setAccountId(2L);
				account2.setAccountType("Current");
				account2.setBalance(23456);
				account2.setCustomer(customer);
				
				accounts.add(account1);
				accounts.add(account2);
				
				customer.setAccounts(accounts);
				
				
				//Set up the mock behavior for the cusrometService.addCustomer method
				
				when(customerService.addCustomer(customer)).thenReturn(customer);
				
				//create a request with the sample customer in the request body
				
				MockHttpServletRequest request= new MockHttpServletRequest();
				
				RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
				
				ResponseEntity<Customer> responseEntity= customerController.createCusomer(customer);
				
				
				//verify the response status code and the customer returned by the controller
				
				assertEquals(HttpStatus.CREATED,responseEntity.getStatusCode());
				
				assertEquals(customer, responseEntity.getBody());
				
				//verfiy that the accounts were added to the customer
				
				assertEquals(2,customer.getAccounts().size());
				
				assertTrue(customer.getAccounts().contains(account1));
				assertTrue(customer.getAccounts().contains(account2));
				
				//verify that the customer was set on the accounts
				
				assertEquals(customer, account1.getCustomer());
				assertEquals(customer,account2.getCustomer());
				

}
	@Test
	public void testGetAllCustomer() throws Exception
	
	{
		//create the sample customers
				Customer customer=new Customer();
			         customer.setCustomerId(1L);
						customer.setCustomerName("peter");
						customer.setEmail("spiderman@example.com");
						
						Customer customer2= new Customer();
						
						customer2.setCustomerId(2L);
						customer2.setCustomerName("Rahul");
						customer2.setEmail("rahul@YopMail");
						
						List<Customer> customers= new ArrayList<>();
						customers.add(customer);
						customers.add(customer2);
						
	 // Set up the mock beahavior
						when(customerService.getAllCustomer()).thenReturn(customers);
						
	//Make the request
						
						MockHttpServletRequest request =new MockHttpServletRequest();
						
						RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
						ResponseEntity<List<Customer>> response= customerController.getAllCustomer();
						
						//Verify the response
						
						assertEquals(HttpStatus.OK, response.getStatusCode());
						List<Customer> responseBody= response.getBody();
						
					assertEquals(2,responseBody.size());
					assertTrue(responseBody.contains(customer));
					assertTrue(responseBody.contains(customer2));
		
	}
	
	
	@Test
	public void testDeleteCustomerById() throws Exception
	{
		Long customerId=1L;
		ResponseEntity<Customer> expectedResponse= ResponseEntity.noContent().build();
		
		//set up the mock behaviour
		
		doNothing().when(customerService).deleteCustomer(customerId);
		
		//Make the request
		
		ResponseEntity<Customer> actualResposnse = customerController.deleteCustomerById(customerId);
		
		//Verify the reposnse
         
		assertEquals(expectedResponse.getStatusCode(),actualResposnse.getStatusCode());

		
		
	}
	
	@Test
	public void testGetCustomerId() throws Exception
	{
		Long customerId=1L;
		Customer customer= new Customer();
		customer.setCustomerId(customerId);
		customer.setCustomerName("Rahul");
		customer.setEmail("rahul@Example.com");
		
		ResponseEntity<Customer> expectedResponse= new ResponseEntity<>(customer,HttpStatus.OK);
		
		//set up the mock behaviour
		
		when(customerService.getCustomerWithAccounts(customerId)).thenReturn(customer);
		
		// Make the request
		
		ResponseEntity<Customer> actualResponse= customerController.getCustomer(customerId);
		
		//verify the response
		assertEquals(expectedResponse.getStatusCode(),actualResponse.getStatusCode());
		assertEquals(expectedResponse.getBody(),actualResponse.getBody());
	}
	
	@Test
	public void testAddAccountToCustomer() throws Exception
	{
		Long customerId=1L;
		Account account= new Account();
		account.setAccountId(1L);
		account.setAccountType("Savings");
		
		ResponseEntity<Void> expectedResponse= ResponseEntity.status(HttpStatus.CREATED).build();
		
		//set up the mock behaviour
		
		doNothing().when(customerService).addAccountToCustomer(customerId, account);
		
		//Make the request
		
		ResponseEntity<Void> actualResponse= customerController.addAccountToCustomer(customerId, account);
		
		//Verify the Response
		assertEquals(expectedResponse.getStatusCode(),actualResponse.getStatusCode());
	}
	

}