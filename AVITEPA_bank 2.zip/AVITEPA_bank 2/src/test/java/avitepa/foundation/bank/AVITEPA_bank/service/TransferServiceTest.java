package avitepa.foundation.bank.AVITEPA_bank.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.repo.AccountRepo;
import avitepa.foundation.bank.AVITEPA_bank.repo.CustomerRepo;

@ExtendWith(MockitoExtension.class)
class TransferServiceTest {

	@InjectMocks

	private TransferService transferservice;

	@Mock

	private CustomerRepo customerrepo;

	@Mock

	private AccountRepo accountrepo;

	@Test
	public void fundtransfer()
	{
	Account account1=new Account();

	Long sourceAccount=1L;

	account1.setAccountId(sourceAccount);

	account1.setBalance(1000.0);

	when(accountrepo.findById(sourceAccount)).thenReturn(Optional.of(account1));

	Account account2=new Account();

	Long targetAccount=2L;

	account2.setAccountId(targetAccount);

	account2.setBalance(500.0);

	when(accountrepo.findById(targetAccount)).thenReturn(Optional.of(account2));

	transferservice.transferFunds(1L,2L,500.0);

	assertEquals(500.0,account1.getBalance(),0.0);

	assertEquals(1000.0,account2.getBalance(),0.0);
	}

	
	
	public void fundtransfer_insufficientfunds()
	{

	Account account1=new Account();

	account1.setAccountId(1L);

	account1.setBalance(500.0);

	when(accountrepo.findById(1L)).thenReturn(Optional.of(account1));

	Account account2=new Account();

	account2.setAccountId(2L);

	account2.setBalance(1000.0);

	when(accountrepo.findById(2L)).thenReturn(Optional.of(account2));
	
	//InsufficientFundsException exception= assertThrows(InsufficientFundsException.class, ()->{transferservice.transferFunds(null, null, null));

//	InsufficientFundsException exception = assertThrows(InsufficientFundsException.class,
//			() ->{transferservice.transferFunds(1L, 2L, 0.0)});
//    //System.out.println(exception.getMessage());
//
	//assertEquals("Insufficient Fund", exception.getMessage());
//
	assertEquals(500.0,account1.getBalance(),0.0);
//
	assertEquals(1000.0,account2.getBalance(),0.0);

	
	}

}
