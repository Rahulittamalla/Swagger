package me20385435.foundation.bank.ME20385435_bank.service;

import java.util.List;

import me20385435.foundation.bank.ME20385435_bank.model.Account;

public interface AccountServiceInterface {

	
	public List<Account> getAllAccounts();
	public void deleteAccountById(int id);
	public List<Account> getByAccountType(String type);
	public Account updateAccount(Account account);
	public Account getAccountByAccountId(int id);
	public String moneyTransfer(int fromId,int toId,double amount);
	public void deleteAll();
	
	
	
	
	
	
	
	
	
	
}
