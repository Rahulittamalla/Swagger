package me20385435.foundation.bank.ME20385435_bank.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExceptionResponse {
	
	private String errorMessage;
	private String requestedURI;
	
}
