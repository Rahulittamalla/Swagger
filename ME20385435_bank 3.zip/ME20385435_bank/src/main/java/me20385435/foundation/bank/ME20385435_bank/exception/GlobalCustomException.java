package me20385435.foundation.bank.ME20385435_bank.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalCustomException extends ResponseEntityExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ResponseBody
	ExceptionResponse handleResourceNotFoundException(ResourceNotFoundException exception, HttpServletRequest request) {
		ExceptionResponse myResponse = new ExceptionResponse();
		myResponse.setErrorMessage(exception.getMessage());
		myResponse.setRequestedURI(request.getRequestURI());
		return myResponse;
	}
    
	@ExceptionHandler(EmptyFieldException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	ExceptionResponse handleEmptyFieldException(EmptyFieldException exception, HttpServletRequest request) {
		ExceptionResponse myResponse = new ExceptionResponse();
		myResponse.setErrorMessage(exception.getMessage());
		myResponse.setRequestedURI(request.getRequestURI());
		return myResponse;
	}
	
	@ExceptionHandler(DuplicateAccountNotAllowedException.class)
	@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
	@ResponseBody
	ExceptionResponse handleDuplicateAccountNotAllowedException(DuplicateAccountNotAllowedException exception, HttpServletRequest request) {
		ExceptionResponse myResponse = new ExceptionResponse();
		myResponse.setErrorMessage(exception.getMessage());
		myResponse.setRequestedURI(request.getRequestURI());
		return myResponse;
	}
	@ExceptionHandler(TransferException.class)
	@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
	@ResponseBody
	ExceptionResponse handleTransferException(TransferException exception, HttpServletRequest request) {
		ExceptionResponse myResponse = new ExceptionResponse();
		myResponse.setErrorMessage(exception.getMessage());
		myResponse.setRequestedURI(request.getRequestURI());
		return myResponse;
	}
	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		return new ResponseEntity<>("check the method Type", HttpStatus.NOT_ACCEPTABLE);
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	ExceptionResponse handleException(Exception exception, HttpServletRequest request) {
		ExceptionResponse myResponse = new ExceptionResponse();
		myResponse.setErrorMessage(exception.getMessage());
		myResponse.setRequestedURI(request.getRequestURI());
		return myResponse;
	}

}
