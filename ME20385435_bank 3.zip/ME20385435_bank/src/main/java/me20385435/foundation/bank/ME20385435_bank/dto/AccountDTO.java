package me20385435.foundation.bank.ME20385435_bank.dto;

import lombok.Data;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
@Data
public class AccountDTO {

	private Account account;

	
}
