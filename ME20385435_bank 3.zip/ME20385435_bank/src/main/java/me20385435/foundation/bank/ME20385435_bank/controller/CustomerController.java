package me20385435.foundation.bank.ME20385435_bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import me20385435.foundation.bank.ME20385435_bank.dto.AccountDTO;
import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.service.CustomerServiceInterface;

/**
 * Customer Controller
 * 
 * @author ME20385435
 * @version 1.0
 * @since 2023-03-31
 */
@RestController
@RequestMapping(value = "/bank")
public class CustomerController {

	@Autowired
	private CustomerServiceInterface service;

	/**
	 * Method Name:getCustomerByCustomerId,This method is used for find customer by
	 * using customerId
	 * 
	 * @param id This is parameter to this method
	 * @return customer and 200 HTTP code
	 */

	@GetMapping("/CustomerId/{id}")
	public ResponseEntity<Customer> getCustomerByCustomerId(@PathVariable int id) {
		Customer cust = service.getCustomerByCustomerId(id);
		return new ResponseEntity<>(cust, HttpStatus.OK);
	}

	/**
	 * Method Name:getCustomerByCustomername, This method is used for find customers
	 * by using customerName
	 * 
	 * @param name This is parameter to this method
	 * @return customers and 200 HTTP code
	 */

	@GetMapping("/CustomerName/{name}")
	public ResponseEntity<List<Customer>> getCustomerByCustomername(@PathVariable String name) {
		List<Customer> cust = service.getCustomerByCustomerName(name);
		return new ResponseEntity<>(cust, HttpStatus.OK);
	}

	/**
	 * Method Name:getCustomerByCustomerNameAndPhno, This method is used for find
	 * customer by using customerName and PhNo
	 * 
	 * @param name This is first parameter to this method
	 * @param phno This is second parameter to this method
	 * @return customer and 200 HTTP code
	 */
	@GetMapping("/CustomerName/{name}/CustomerPhno/{phno}")
	public ResponseEntity<Customer> getCustomerByCustomerNameAndPhno(@PathVariable String name,
			@PathVariable String phno) {
		Customer cust = service.getCustomerByCustomerNameAndCustomerPhno(name, phno);
		return new ResponseEntity<>(cust, HttpStatus.OK);
	}

	/**
	 * Method Name: getCustomerByAccountTypeAndCustomerNameAndPhno, This method is
	 * used for find customer by using customerName,accountType and PhNo
	 * 
	 * @param name        This is first parameter to this method
	 * @param phno        This is second parameter to this method
	 * @param accountType This is Third parameter to this method
	 * @return customer and 200 HTTP code
	 */
	@GetMapping("/CustomerName/{name}/CustomerPhno/{phno}/accountType/{accountType}")
	public ResponseEntity<Customer> getCustomerByAccountTypeAndCustomerNameAndPhno(@PathVariable String name,
			@PathVariable String phno, @PathVariable String accountType) {
		Customer cust = service.getCustomerByCustomerNameAndAccountTypeAndCustomerPhno(name, phno, accountType);
		return new ResponseEntity<>(cust, HttpStatus.OK);
	}

	/**
	 * Method Name: getAccountByAccountType, This method is used for find customers
	 * by using accountType
	 * 
	 * @param type This is parameter to this method
	 * @return customers and 200 HTTP code
	 */
	@GetMapping("/AccountType/{type}")
	public ResponseEntity<List<Customer>> getAccountByAccountType(@PathVariable String type) {
		List<Customer> cs = service.getCustomerByAccountType(type);
		return new ResponseEntity<>(cs, HttpStatus.OK);
	}

	/**
	 * Method Name:getAll, This method is used for find all customers
	 * 
	 * @return customers and 200 HTTP code
	 */
	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAll() {
		List<Customer> cs = service.getAllCustomers();
		return new ResponseEntity<>(cs, HttpStatus.OK);
	}

	/**
	 * Method Name:getCustomerByAccountId, This method is used for find customer by
	 * using AccountId
	 * 
	 * @param id This is parameter to this method
	 * @return customer and 200 HTTP code
	 */
	@GetMapping("/Customer/AccountId/{id}")
	public ResponseEntity<Customer> getCustomerByAccountId(@PathVariable int id) {
		Customer cs = service.getCustomerByAccountId(id);
		return new ResponseEntity<>(cs, HttpStatus.OK);
	}

	/**
	 * Method Name:addCustomer, This method is used for add new Customer
	 * 
	 * @param customer This is parameter to this method
	 * @return 201 HTTP code
	 */
	@PostMapping("/add")
	public ResponseEntity<CustomerDTO> addCustomer(@RequestBody CustomerDTO customer) {
		service.addCustomer(customer);
		return new ResponseEntity<>(customer, HttpStatus.CREATED);

	}

	/**
	 * Method Name:updateCustomer, This method is used for update the Customer
	 * 
	 * @param customer This is parameter to this method
	 * @return 201 HTTP code
	 */

	@PutMapping("/updateCustomer")
	public ResponseEntity<Customer> updateCustomer(@RequestBody CustomerDTO customer) {
		Customer updatedCustomer=service.updateCustomer(customer.getCustomer());
		return new ResponseEntity<>(updatedCustomer, HttpStatus.CREATED);

	}

	/**
	 * Method Name: deleteCustomerById, This method is used for delete the Customer
	 * by using customerId
	 * 
	 * @param id This is parameter to this method
	 * @return 202 HTTP code
	 */
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCustomerById(@PathVariable int id) {
		service.deleteByCustomerId(id);
		return new ResponseEntity<>("Deleted  successfully", HttpStatus.ACCEPTED);
	}

	/**
	 * Method Name:deleteAll, This method is used for delete all customers
	 * 
	 * @return 202 HTTP code
	 */
	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteAll() {
		service.deleteAll();
		return new ResponseEntity<>("Deleted All Data", HttpStatus.ACCEPTED);
	}

	/**
	 * Method Name:addAccount, This method is used to add account by using
	 * customerId
	 * 
	 * @param id      This is first parameter to this method
	 * @param account This is second parameter to this method
	 * @return account and 201 HTTP code
	 */

	@PostMapping("/addAccount/{id}")
	public ResponseEntity<AccountDTO> addAccount(@PathVariable int id, @RequestBody AccountDTO account) {
		service.addAccount(id, account.getAccount());
		return new ResponseEntity<>(account, HttpStatus.CREATED);

	}

}
