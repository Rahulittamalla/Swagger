package me20385435.foundation.bank.ME20385435_bank.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
public class TransferException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TransferException (String msg) {
		super(msg);
	}
}