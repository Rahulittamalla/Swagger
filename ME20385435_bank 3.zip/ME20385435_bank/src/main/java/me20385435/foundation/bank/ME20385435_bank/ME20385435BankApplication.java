package me20385435.foundation.bank.ME20385435_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

@SpringBootApplication
public class ME20385435BankApplication {

	public static void main(String[] args) {
		SpringApplication.run(ME20385435BankApplication.class, args);
	}

	@Profile("test")
	@Bean
	public String testBean() {
		return "test";
	}

	@Profile("prod")
	@Bean
	public String prodBean() {
		return "prod";
	}
	
	
}
