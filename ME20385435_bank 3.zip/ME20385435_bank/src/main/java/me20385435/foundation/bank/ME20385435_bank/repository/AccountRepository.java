package me20385435.foundation.bank.ME20385435_bank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {

	public List<Account> findByAccountType(String accountType);
	    
	
	@Query("SELECT c FROM Customer c JOIN c.account a where a.accountId=:accountId")
    public Customer findByAccountId(@Param("accountId") int accountId);
	

	
	
	@Query("SELECT c FROM Customer c JOIN  c.account a where c.customerId=:customerId and a.accountType=:accountType")
    public Customer findByAccountTypeAndCustomerId(@Param("accountType") String accountType,@Param("customerId") int customerId);
    
}
