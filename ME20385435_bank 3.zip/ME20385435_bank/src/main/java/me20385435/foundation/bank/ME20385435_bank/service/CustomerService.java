package me20385435.foundation.bank.ME20385435_bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;
import me20385435.foundation.bank.ME20385435_bank.exception.DuplicateAccountNotAllowedException;
import me20385435.foundation.bank.ME20385435_bank.exception.EmptyFieldException;
import me20385435.foundation.bank.ME20385435_bank.exception.ResourceNotFoundException;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.repository.AccountRepository;
import me20385435.foundation.bank.ME20385435_bank.repository.CustomerRepository;

@Service
public class CustomerService implements CustomerServiceInterface {

	@Autowired
	private CustomerRepository crepo;

	@Autowired
	private AccountRepository arepo;

	@Value("${msg}")
	private String msg;

	// This is DeleteCustomer Method by using Id
	@Override
	public void deleteByCustomerId(int id) {

		/*
		 * checking for customer Exists or not by using Id .If not it throws
		 * ResourceNotFoundException
		 */

		Customer c = crepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(msg + id));

		// delete Customer
		crepo.delete(c);

	}

	// This is add Customer Method

	@Override
	public Customer addCustomer(CustomerDTO customer) {

		// checking the fields empty or not. if empty it throws EmptyFieldException

		if (customer.getCustomer().getCustomerPhno() == null || customer.getCustomer().getCustomerName() == null
				|| customer.getCustomer().getCustomerEmail() == null) {

			throw new EmptyFieldException("Fields Must not be empty");
		}

		// checking the customer phone number already exists or not in the database.

		Customer c = getCustomerByCustomerPhno(customer.getCustomer().getCustomerPhno());

		// if exists it throws DuplicateAccountNotAllowedException
		if (c != null) {
			throw new DuplicateAccountNotAllowedException(
					"Customer already exists with this phno:" + customer.getCustomer().getCustomerPhno());
		}

		// add customer logic
		else {

			Customer cs = crepo.save(customer.getCustomer());
			List<Account> accountList = new ArrayList<>();
			accountList.addAll(customer.getCustomer().getAccount());

			// checking for duplicate accounts
			for (Account a : accountList) {
				for (Account ae : accountList) {

					if (ae.getAccountType().equalsIgnoreCase(a.getAccountType())

							&& ae.getAccountId() != a.getAccountId()) {

						crepo.deleteById(cs.getCustomerId());

						throw new DuplicateAccountNotAllowedException(

								"Duplicate Account type!!.Same account type cannot exist for the  same customer");

					}

				}
			}
			// return the customer
			return cs;
		}
	}

	// This is update Customer Method

	@Override
	public Customer updateCustomer(Customer customer) {

		/*
		 * checking for customer Exists or not by using Id .If not it throws
		 * ResourceNotFoundException
		 */

		Customer cs = crepo.findById(customer.getCustomerId()).orElseThrow(() -> new ResourceNotFoundException(msg));
		if (cs != null) {
			List<Account> accounts = new ArrayList<>();
			accounts.addAll(cs.getAccount());
			List<Account> accountList = new ArrayList<>();
			accountList.addAll(customer.getAccount());

			// checking for duplicate accounts

			for (Account a : accounts) {
				for (Account account1 : accountList) {
					if (a.getAccountType().equalsIgnoreCase(account1.getAccountType())
							&& a.getAccountId() != account1.getAccountId()) {
						throw new DuplicateAccountNotAllowedException(
								"one Customer cannot have same  type of Accounts");
					}
				}
			}
			// updating customer details

			cs.setCustomerId(customer.getCustomerId());
			cs.setCustomerName(customer.getCustomerName());
			cs.setCustomerEmail(customer.getCustomerEmail());
			cs.setCustomerPhno(customer.getCustomerPhno());
			cs.setAccount(customer.getAccount());
			crepo.save(cs);
		}
		// return updated Customer

		return cs;
	}

	// This is GetCustomerByCustomerId Method
	@Override
	public Customer getCustomerByCustomerId(int id) {

		/*
		 * checking for customer Exists or not by using Id .If not it throws
		 * ResourceNotFoundException.
		 * return the Customer
		 */
		
		return crepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(msg + id));

	}

	// This is GetAllCustomers Method
	@Override
	public List<Customer> getAllCustomers() {

		// Getting all customers data from database.

		List<Customer> custs = crepo.findAll();

		// If no data available it throws ResourceNotFoundException.
		if (custs.isEmpty())
			throw new ResourceNotFoundException(" Customers Data is Empty");

		// returning the customers data

		return custs;
	}

	// This is GetCustomerByCustomerName Method
	@Override
	public List<Customer> getCustomerByCustomerName(String name) {

		// checking for customers Exists or not by using Name .

		List<Customer> customers = crepo.findByCustomerName(name);
		// If not it throws ResourceNotFoundException.
		if (customers.isEmpty())
			throw new ResourceNotFoundException("No customer Exists with that name:" + name);
		else
			// return the Customers
			return customers;

	}

	// This is GetCustomerByCustomerNameAndCustomerPhno method
	@Override
	public Customer getCustomerByCustomerNameAndCustomerPhno(String name, String phno) {

		// checking for customer Exists or not by using Name and Phone number .

		Customer c = crepo.findByCustomerNameAndCustomerPhno(name, phno);

		// If not it throws ResourceNotFoundException.
		if (c == null)
			throw new ResourceNotFoundException("No customer Exists with that Name:" + name + " And Phno:" + phno);

		// return the Customer
		return c;

	}

	// This is GetCustomerByCustomerNameAndAccountTypeAndCustomerPhno method

	@Override
	public Customer getCustomerByCustomerNameAndAccountTypeAndCustomerPhno(String name, String phno,
			String accountType) {

		// checking for customer Exists or not by using Name,AccountType, and Phone.

		Customer c = crepo.getByCustomerNameAndCustomerPhnoAndAccountType(name, phno, accountType);

		// If not it throws ResourceNotFoundException.
		if (c == null)
			throw new ResourceNotFoundException("No customer Exists with that Name:" + name + "," + "accountType:"
					+ accountType + "And Phno:" + phno);

		// return the customer

		return c;

	}

	// This is GetCustomerByCustomerEmail method
	@Override
	public Customer getCustomerByCustomerEmail(String email) {

		// checking for customers Exists or not by using Email .

		Customer customer = crepo.findByCustomerEmail(email);

		// If not it throws ResourceNotFoundException.
		if (customer == null)
			throw new ResourceNotFoundException("No customer Exists with that Email:" + email);

		// return the Customer
		return customer;
	}

	// This is delete method
	@Override
	public void deleteAll() {
		// delete Total customers data
		crepo.deleteAll();

	}

	// This is GetCustomerByAccountId method.

	@Override
	public Customer getCustomerByAccountId(int id) {
		// checking for customer Exists or not by using Account Id .

		Customer cs = crepo.findByAccountId(id);
		// If not it throws ResourceNotFoundException.
		if (cs == null)
			throw new ResourceNotFoundException("No customer Exists with accountId: " + id);

		// return the Customer
		return cs;
	}

	// This is GetCustomerByAccountType method
	@Override
	public List<Customer> getCustomerByAccountType(String accountType) {
		// checking for customer Exists or not by using Account Type .

		List<Customer> cs = crepo.findByAccountType(accountType);
		// If not it throwsResourceNotFoundException.
		if (cs.isEmpty())
			throw new ResourceNotFoundException("No customer Exists with this accountTyep: " + accountType);
		// return the Customer
		return cs;

	}

	// This is GetByCustomerPhnoAndAccountType method.
	@Override
	public Customer getByCustomerPhnoAndAccountType(String phno, String type) {
		// checking for customer Exists or not by using phone number and Account Type.

		Customer cs = crepo.getByCustomerPhnoAndAccountType(phno, type);
		// If not it throws ResourceNotFoundException.
		if (cs == null)
			throw new ResourceNotFoundException("No customer Exists with phno:" + phno + " and type:" + type);

		// return the Customer
		return cs;

	}

	// This is GetCustomerByCustomerPhno method.
	@Override
	public Customer getCustomerByCustomerPhno(String phno) {

		// return the Customer
		return crepo.findByCustomerPhno(phno);

	}

	// This is addAccount method by using CustomerId.
	@Override
	public List<Account> addAccount(int id, Account account) {
		List<Account> accounts = new ArrayList<>();
		accounts.add(account);

		/*
		 * checking for customer Exists or not by using Id .If not it throws
		 * ResourceNotFoundException
		 */

		Customer customer = crepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(msg + id));
		if (customer != null) {

			// checking for Duplicate Accounts.

			if (customer.getAccount().stream().anyMatch(a -> a.getAccountType().equals(account.getAccountType()))) {
				throw new DuplicateAccountNotAllowedException("one Customer cannot have same  type of Accounts");
			} else {

				// add new Account
				accounts.addAll(customer.getAccount());
				customer.setAccount(accounts);
				return arepo.saveAll(accounts);
			}
		}
		// return the Accounts
		return accounts;
	}

}
