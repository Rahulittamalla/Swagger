package me20385435.foundation.bank.ME20385435_bank.exception;


public class ResourceNotFoundException extends RuntimeException  {

	private static final long serialVersionUID = 1L;

	public ResourceNotFoundException(String msg) {
		super(msg);
	}

	

	
	

	
	
	
}
