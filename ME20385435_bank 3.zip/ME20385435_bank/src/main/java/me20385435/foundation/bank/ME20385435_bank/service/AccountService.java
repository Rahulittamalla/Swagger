package me20385435.foundation.bank.ME20385435_bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Service;

import me20385435.foundation.bank.ME20385435_bank.exception.DuplicateAccountNotAllowedException;
import me20385435.foundation.bank.ME20385435_bank.exception.ResourceNotFoundException;
import me20385435.foundation.bank.ME20385435_bank.exception.TransferException;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.repository.AccountRepository;

@Service
public class AccountService implements AccountServiceInterface {

	@Autowired
	private AccountRepository arepo;

	@Value("${mssg}")
	private String msg;

	// This is GetAllAccounts method.

	@Override
	public List<Account> getAllAccounts() {

		
		 // Getting all accounts from database. 

		List<Account> accounts = arepo.findAll();
		
		// if no accounts available it throwsResourceNotFoundException
		if (accounts.isEmpty())
			throw new ResourceNotFoundException("Data is Empty");
		else
			// return the accounts
			return accounts;
	}

	// This is GetAccountByAccountId method.
	@Override
	public Account getAccountByAccountId(int id) {

		/*
		 * checking for Account Exists or not by using Id .If not it throws
		 * ResourceNotFoundException else return the account
		 */
		return arepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(msg + id));
	}

	// This is DeleteAccountById method.

	@Override
	public void deleteAccountById(int id) {
		/*
		 * checking for Account Exists or not by using Id .If not it throws
		 * ResourceNotFoundException else delete account
		 */
		Account account = arepo.findById(id).orElseThrow(() -> new ResourceNotFoundException(msg + id));
		arepo.delete(account);
	}

	// This is GetByAccountType method.

	@Override
	public List<Account> getByAccountType(String type) {

		// checking for Account Exists or not by using Id.

		List<Account> accounts = arepo.findByAccountType(type);
		
		// If not it throwsResourceNotFoundException
		
		if (accounts.isEmpty())
			throw new ResourceNotFoundException("No Data Found with AccountType");
		else
			// return the accounts
			return accounts;

	}

	// This is updateAccount method.

	@Override
	public Account updateAccount(Account account) {

		/*
		 * checking for Account Exists or not by using Id.If not it throws
		 * ResourceNotFoundException
		 */
		Account account1 = arepo.findById(account.getAccountId())
				.orElseThrow(() -> new ResourceNotFoundException(msg + account.getAccountId()));

		// updating the account
		account1.setAccountId(account.getAccountId());
		account1.setAccountType(account.getAccountType());
		account1.setAccountBalance(account.getAccountBalance());
		
		// check the customer by using AccountId
		Customer customer = arepo.findByAccountId(account1.getAccountId());
		List<Account> accountslist = new ArrayList<>();

		accountslist.addAll(customer.getAccount());

		// check for Duplicate Accounts
		for (Account a : accountslist) {
			if (a.getAccountType().equalsIgnoreCase(account1.getAccountType())
					&& a.getAccountId() != account1.getAccountId()) {
				throw new DuplicateAccountNotAllowedException("one Customer cannot have same  type of Accounts");
			}
		}
		// update Account
		arepo.save(account1);

		// return the account
		return account;
	}

	// This is moneyTransfer method.
	
	@Override
	public String moneyTransfer(int fromId, int toId, double amount) {

		// checking the accounts Exists or not
		
		Account from = getAccountByAccountId(fromId);
		Account to = getAccountByAccountId(toId);

		double fromAmount = from.getAccountBalance();
		double toAmount = to.getAccountBalance();

		// verifying the accountIds same or not
		if (from.getAccountId() == to.getAccountId())
			throw new TransferException("amount cannnot transfer to self Account");

		// checking the balance less than zero or equal to zero
		if (amount <= 0) {
			throw new TransferException("amount must be greater than zero ");
		}

		/*check the sufficient balance available or not and Transfer Money one account
		 to other account*/
		if (fromAmount >= amount) {
			fromAmount = fromAmount - amount;
			toAmount = toAmount + amount;
			from.setAccountBalance(fromAmount);
			to.setAccountBalance(toAmount);
			arepo.save(from);
			arepo.save(to);
			return "Money Successfully Transfered!" + "\n" + "From Account TotalAvailableBalance :" + fromAmount + "\n"
					+ " " + "To Amount TotalAvailableBalance :" + toAmount;
		} else
			// throwing Exception
			throw new TransferException("Insufficient Balance ");

	}

	// This is deleteAll method
	@Override
	public void deleteAll() {
		// delete all accounts
		arepo.deleteAll();
	}

}
