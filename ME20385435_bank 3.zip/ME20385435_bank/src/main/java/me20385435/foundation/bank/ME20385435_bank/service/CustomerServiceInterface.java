package me20385435.foundation.bank.ME20385435_bank.service;

import java.util.List;

import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;

public interface CustomerServiceInterface {

  public void deleteByCustomerId(int id);
  public Customer addCustomer(CustomerDTO customer);
  public Customer updateCustomer(Customer customer);
  public Customer getCustomerByCustomerId(int id);
  public List<Customer> getAllCustomers() ;
  public List<Customer> getCustomerByCustomerName(String name);
  public Customer getCustomerByCustomerEmail(String email);
  public Customer getCustomerByCustomerNameAndCustomerPhno(String name,String phno);
  public Customer getCustomerByCustomerNameAndAccountTypeAndCustomerPhno(String name,String phno,String accountType);
  public void deleteAll();
  public List<Customer> getCustomerByAccountType(String accountType);
  public Customer getCustomerByAccountId(int id);
  public Customer getByCustomerPhnoAndAccountType(String phno,String type);
  public Customer getCustomerByCustomerPhno(String phno);
  public  List<Account> addAccount(int id,Account account);

  
}
