package me20385435.foundation.bank.ME20385435_bank.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import me20385435.foundation.bank.ME20385435_bank.model.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	
	public List<Customer> findByCustomerName(String customerName);
	
	public Customer findByCustomerEmail(String customerEmail);
	
	public Customer findByCustomerNameAndCustomerPhno(String customerName,String customerPhno);
	
	
	@Query("SELECT c FROM Customer c JOIN c.account a where c.customerPhno=:customerPhno and a.accountType=:accountType")
	public Customer getByCustomerPhnoAndAccountType(@Param("customerPhno") String customerPhno ,@Param("accountType") String accountType);
	
	@Query("SELECT c FROM Customer c JOIN c.account a where c.customerName=:customerName and c.customerPhno=:customerPhno and a.accountType=:accountType")
	public Customer getByCustomerNameAndCustomerPhnoAndAccountType(@Param("customerName") String customerName ,@Param("customerPhno") String customerPhno ,@Param("accountType") String accountType);
	
    @Query("SELECT c FROM Customer c JOIN c.account a where a.accountType=:accountType")
    public List<Customer> findByAccountType(@Param("accountType") String accountType);
	
    @Query("SELECT c FROM Customer c JOIN c.account a where a.accountId=:accountId")
    public Customer findByAccountId(@Param("accountId") int accountId);

    @Query("SELECT c FROM Customer c JOIN  c.account a where c.customerId=:customerId and a.accountType=:accountType")
    public Customer findByAccountTypeAndCustomerId(@Param("accountType") String accountType,@Param("customerId") int customerId);
    
    
    public Customer findByCustomerPhno(String customerPhno);
    

    
    
}
