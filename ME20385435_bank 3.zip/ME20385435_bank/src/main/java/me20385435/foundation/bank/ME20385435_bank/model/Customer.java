package me20385435.foundation.bank.ME20385435_bank.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="Customer_Table")
public class Customer implements Serializable{

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int customerId;
	private String customerName;
	private String customerPhno;
	private String customerEmail;
	
	
	@OneToMany(cascade= {CascadeType.ALL},fetch = FetchType.EAGER)
	@JoinColumn(name="cid_aid",referencedColumnName="customerId")
	private List<Account> account;


	public Customer(int customerId, String customerName, String customerPhno, String customerEmail) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhno = customerPhno;
		this.customerEmail = customerEmail;
	}


	
	

	

	

	

	
	
	
	
	
	
	
}
