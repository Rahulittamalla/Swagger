package me20385435.foundation.bank.ME20385435_bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import me20385435.foundation.bank.ME20385435_bank.dto.AccountDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.service.AccountServiceInterface;



@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	private AccountServiceInterface service;
	
	@GetMapping("/AccountId/{id}")
	public ResponseEntity<Account> getAccountByAccountId(@PathVariable int id){
		Account acc=service.getAccountByAccountId(id);
		return  new ResponseEntity<>(acc,HttpStatus.OK);
	}
	
	@GetMapping("/Account/{type}")
	public ResponseEntity<List<Account>> getAccountByAccountId(@PathVariable String type){
		List<Account> acc=service.getByAccountType(type);
		return  new ResponseEntity<>(acc,HttpStatus.OK);
	}
	
	@GetMapping("/getAllAccounts")
	public ResponseEntity<List<Account>> getAccounts(){
		List<Account> acc=service.getAllAccounts();
		return  new ResponseEntity<>(acc,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/AccountId/{id}")
	public ResponseEntity<String> deleteByAccountId(@PathVariable int id){
		service.deleteAccountById(id);
		return  new ResponseEntity<>("Account Deleted Succefully!",HttpStatus.ACCEPTED);
	}
	
	@PutMapping("/updateAccount")
	public ResponseEntity<String> updateAccount(@RequestBody AccountDTO account){
		service.updateAccount(account.getAccount());
		return  new ResponseEntity<>(" Account Updated Succefully!",HttpStatus.CREATED);
	}

	@PostMapping("/transfer/from/{fromId}/To/{toId}/amount/{amount}")
	public ResponseEntity<String> Transfer(@PathVariable int fromId, @PathVariable int toId,@PathVariable double amount){
		
		String accDetails=service.moneyTransfer(fromId, toId, amount);
		
		return  new ResponseEntity<>(accDetails,HttpStatus.CREATED);
	}
	@DeleteMapping("/deleteAccounts")
	public ResponseEntity<String> deleteAllAccounts(){
	service.deleteAll();
	return new ResponseEntity<>("Complete Data has been Deleted!!!",HttpStatus.ACCEPTED);
	}
	
}
