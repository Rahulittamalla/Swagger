package me20385435.foundation.bank.ME20385435_bank.controllerTesting;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import me20385435.foundation.bank.ME20385435_bank.controller.AccountController;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.service.AccountService;

@WebMvcTest(value = AccountController.class)
@TestMethodOrder(OrderAnnotation.class)
class AccountControllerTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private AccountService service;

	@Test
	@Order(1)
	@DisplayName("Test : Get All Accounts")
	void test_getAllAccount() throws Exception {

		Account account = new Account(1, "Savings", 50000);
		List<Account> accounts = new ArrayList<>();
		accounts.add(account);
		when(service.getAllAccounts()).thenReturn(accounts);
		this.mockMvc.perform(get("/account/getAllAccounts"))
		.andExpect(status().isOk());

	}

	@Test
	@Order(2)
	@DisplayName("Test : Get Account By AccountID")
	void test_getAccountByAccountId() throws Exception {

		Account account = new Account();
		account.setAccountId(1);
		account.setAccountType("Savings");
		account.setAccountBalance(100000);

		mockMvc.perform(get("/account/AccountId/{id}", account.getAccountId())).andExpect(status().isOk());
	}

	@Test
	@Order(3)
	@DisplayName("Test : Get Account By Account Type")
	void test_getAccountByAccountType() throws Exception {

		Account account = new Account();
		account.setAccountId(1);
		account.setAccountType("Savings");
		account.setAccountBalance(100000);

		mockMvc.perform(get("/account/Account/{type}", account.getAccountType())).andExpect(status().isOk());
	}

	@Test
	@Order(4)
	@DisplayName("Test : Money Transfer")
	void test_MoneyTransfer() throws Exception {

		Account account1 = new Account();
		account1.setAccountId(1);
		account1.setAccountType("Savings");
		account1.setAccountBalance(200000);

		Account account2 = new Account();
		account2.setAccountId(2);
		account2.setAccountType("Savings");
		account2.setAccountBalance(100000);

		List<Account> accounts = new ArrayList<>();
		accounts.add(account1);
		accounts.add(account2);

		when(service.moneyTransfer(1, 2, 50000)).thenReturn("Money Sent Successfully!!!");
		this.mockMvc
				.perform(post("/account/transfer/from/{fromId}/To/{toId}/amount/{amount}", 1, 2, 50000)
						.contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(accounts)))
				.andExpect(status().isCreated());
	}

	@Test
	@Order(5)
	@DisplayName("Test : Update Account")
	void test_updateAccount() throws Exception {

		Account account = new Account(1, "Savings", 50000);
		when(service.updateAccount(account)).thenReturn(account);
		this.mockMvc.perform(put("/account/updateAccount").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(account))).andExpect(status().isCreated());

	}

	@Test
	@Order(6)
	@DisplayName("Test : Delete Account By AccountID")
	void test_deleteAccountByAccountId() throws Exception {

		doNothing().when(service).deleteAccountById(anyInt());
		this.mockMvc.perform(delete("/account/AccountId/{id}", 1)).andExpect(status().isAccepted());
	}
	@Test
	@Order(7)
	@DisplayName("Test : Delete All Accounts")
	void test_deleteAll() throws Exception{
	doNothing().when(service).deleteAll();
	this.mockMvc.perform(delete("/account/deleteAccounts"))
	.andExpect(status().isAccepted());

	}
	
	
}