package me20385435.foundation.bank.ME20385435_bank.IntegrationCustomerTesting;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import me20385435.foundation.bank.ME20385435_bank.dto.AccountDTO;
import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;

import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.repository.CustomerRepository;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(OrderAnnotation.class)
@ActiveProfiles("test")
class CustomerIntergrationTest {
     
	
	@LocalServerPort
	private int port;

	private String baseUrl = "http://localhost";

	private static RestTemplate restTemplate;

	@Autowired
	private CustomerRepository customerRepository;

	@BeforeAll
	public static void init() {
		restTemplate = new RestTemplate();
	}

	@BeforeEach
	public void beforeSetUp() {
		baseUrl = baseUrl + ":" + port + "/bank";
	}
  
    
	@Test
	@Order(1)
	void test_AddCustomer() {

		Account accounts1 = new Account(5, "savings", 50000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		CustomerDTO cdto = new CustomerDTO();
		Customer customers = new Customer(1,"Raji", "6307766888", "raji@gmail.com", account);
		cdto.setCustomer(customers);
		ResponseEntity<CustomerDTO> responseEntity = restTemplate.postForEntity(baseUrl+"/add",cdto, CustomerDTO.class);
		assertNotNull(responseEntity);
		assertEquals(201, responseEntity.getStatusCodeValue());
        assertEquals(customers,responseEntity.getBody().getCustomer());
	}

	@Test
	@Order(2)
	void test_AddAccountException()  {
		Account account = new Account(5, "savings", 50000);
		AccountDTO adto=new AccountDTO();
		adto.setAccount(account);
		assertThrows(HttpClientErrorException.class,()->
		
		{
			restTemplate.postForEntity(baseUrl+"/addAccount/"+1,adto, AccountDTO.class);
			
		}
	);
		
	}
	@SuppressWarnings("rawtypes")
	@Test
	@Order(3)
	void test_getAllCustomer() {

	    ResponseEntity<List> responseEntity=restTemplate.getForEntity(baseUrl+"/getAllCustomers", List.class);
	    assertNotNull(responseEntity);
        assertEquals(200, responseEntity.getStatusCodeValue());
	}
	
	
	@Test
	@Order(4)
	void test_getCustomerById() {
		ResponseEntity<Customer> responseEntity=restTemplate.getForEntity(baseUrl+"/CustomerId/"+1, Customer.class);
		
		assertEquals(200, responseEntity.getStatusCodeValue());
        assertEquals("Raji",responseEntity.getBody().getCustomerName());
	}
	@Test
	@Order(5)
	void test_getCustomerByName() {
		@SuppressWarnings("rawtypes")
		ResponseEntity<List> responseEntity=restTemplate.getForEntity(baseUrl+"/CustomerName/"+"Raji", List.class);
		assertEquals(200, responseEntity.getStatusCodeValue());
		assertNotNull(responseEntity);
	}
	@Test
	@Order(6)
	void test_getCustomerByNameAndPhno() {
		ResponseEntity<Customer> responseEntity=restTemplate.getForEntity(baseUrl+"/CustomerName/"+"Raji"+"/CustomerPhno/"+"6307766888", Customer.class);
		assertEquals(200, responseEntity.getStatusCodeValue());
		assertNotNull(responseEntity);
		assertEquals("raji@gmail.com",responseEntity.getBody().getCustomerEmail());
	}
	@Test
	@Order(7)
	void test_getCustomerByNameAndPhnoAndAccountType() {
		ResponseEntity<Customer> responseEntity=restTemplate.getForEntity(baseUrl+"/CustomerName/"+"Raji"+"/CustomerPhno/"+"6307766888"+"/accountType/"+"savings", Customer.class);
		assertEquals(200, responseEntity.getStatusCodeValue());
		assertNotNull(responseEntity);
		assertEquals("Raji",responseEntity.getBody().getCustomerName());
	}
	@Test
	@Order(8)
	void test_getCustomerByAccountType() {
		@SuppressWarnings("rawtypes")
		ResponseEntity<List> responseEntity=restTemplate.getForEntity(baseUrl+"/AccountType/"+"savings", List.class);
		assertEquals(200, responseEntity.getStatusCodeValue());
		assertNotNull(responseEntity);
	}
	@Test
	@Order(9)
	void test_updateCustomer() {
		HttpHeaders headers = new HttpHeaders();
		Account accounts1 = new Account(6, "current", 60000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		CustomerDTO cdto = new CustomerDTO();
		Customer customers = new Customer(1,"Raji", "6307766889", "raji1@gmail.com", account);
		cdto.setCustomer(customers);
	    HttpEntity<CustomerDTO> httpEntity = new HttpEntity<CustomerDTO>(cdto, headers);
	    ResponseEntity<CustomerDTO> responseEntity = restTemplate.exchange(baseUrl+"/updateCustomer",
                HttpMethod.PUT, httpEntity, CustomerDTO.class);

        assertEquals(201, responseEntity.getStatusCodeValue());
      
	}
	
	@Test
	@Order(10)
	void test_deleteCustomerById() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<String>(null, headers);
	    ResponseEntity<String> responseEntity = restTemplate.exchange(baseUrl+"/delete/"+1,
                HttpMethod.DELETE, httpEntity, String.class);

        assertEquals(202, responseEntity.getStatusCodeValue());
      
	}
	
	@Test
	@Order(11)
	void test_deleteCustomerByIdException() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<String>(null, headers);
	     assertThrows(HttpClientErrorException.class,()->
	     {restTemplate.exchange(baseUrl+"/delete/"+1,
                HttpMethod.DELETE, httpEntity, String.class);
	     });

        
      
	}
	
	@Test
	@Order(12)
	void deleteAll() {
		customerRepository.deleteAll();
		assertEquals(0,customerRepository.count());
	}
	
}
