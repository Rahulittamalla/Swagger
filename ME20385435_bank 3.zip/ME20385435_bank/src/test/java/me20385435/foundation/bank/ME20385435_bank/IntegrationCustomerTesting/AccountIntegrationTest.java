package me20385435.foundation.bank.ME20385435_bank.IntegrationCustomerTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;


import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.repository.AccountRepository;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(OrderAnnotation.class)
@ActiveProfiles("test")
class AccountIntegrationTest {

	
	@LocalServerPort
	private int port;

	private String baseUrl = "http://localhost";

	private static RestTemplate restTemplate;
	
	
	@BeforeAll
	public static void init() {
		restTemplate = new RestTemplate();
	}

	@BeforeEach
	public void beforeSetUp() {
		baseUrl = baseUrl + ":" + port + "/account";
	}
	@Autowired
	private AccountRepository accountRepository;
	
	@Test
	@Order(2)
	void test_getAllAccounts() {
	    @SuppressWarnings("rawtypes")
		ResponseEntity<List> responseEntity=restTemplate.getForEntity(baseUrl+"/getAllAccounts", List.class);
	    assertNotNull(responseEntity);
        assertEquals(200, responseEntity.getStatusCodeValue());
	}
	@Test
	@Order(3)
	void test_getAccountByAccountType() {
	    @SuppressWarnings("rawtypes")
		ResponseEntity<List> responseEntity=restTemplate.getForEntity(baseUrl+"/Account/"+"savings", List.class);
	    assertNotNull(responseEntity);
        assertEquals(200, responseEntity.getStatusCodeValue());
	}
	@Test
	@Order(4)
	void test_getAccountByAccountId() {
		ResponseEntity<String> responseEntity=restTemplate.getForEntity(baseUrl+"/AccountId/"+1, String.class);
	    assertNotNull(responseEntity);
        assertEquals(200, responseEntity.getStatusCodeValue());
	}
	
	@Test
	@Order(5)
	void test_deleteAccountById() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<String>(null, headers);
	    ResponseEntity<String> responseEntity = restTemplate.exchange(baseUrl+"/AccountId/"+1,
                HttpMethod.DELETE, httpEntity, String.class);

        assertEquals(202, responseEntity.getStatusCodeValue());
      
	}
	

	
	@Test
	@Order(1)
	void test_TransferMoney() {
		Account account=new Account(1,"savings",50000);
        accountRepository.save(account);
		Account account1=new Account(2,"savings",5000);
        accountRepository.save(account1);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<String>(null, headers);
	    ResponseEntity<String> responseEntity = restTemplate.exchange(baseUrl+"/transfer/from/"+1+"/To/"+2+"/amount/"+3000,
                HttpMethod.POST, httpEntity, String.class);
        assertEquals(201, responseEntity.getStatusCodeValue());
      
	}
	
	@Test
	@Order(6)
	void test_deleteAccounts() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<String>(null, headers);
	    ResponseEntity<String> responseEntity = restTemplate.exchange(baseUrl+"/deleteAccounts",
                HttpMethod.DELETE, httpEntity, String.class);

        assertEquals(202, responseEntity.getStatusCodeValue());
      
	}
	
	
}
