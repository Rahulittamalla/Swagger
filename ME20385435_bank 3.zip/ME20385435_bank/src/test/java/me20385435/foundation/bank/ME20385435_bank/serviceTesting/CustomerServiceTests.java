package me20385435.foundation.bank.ME20385435_bank.serviceTesting;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.repository.CustomerRepository;
import me20385435.foundation.bank.ME20385435_bank.service.CustomerService;

@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest
class CustomerServiceTests{


	@Mock
	private CustomerRepository crepo;

	@InjectMocks
	private CustomerService service;


	public List<Customer> customers;

	@Test
	@Order(1)
	void test_getAllCustomers() {

		Account accounts1 = new Account(1, "Savings", 50000);
		Account accounts2 = new Account(2, "Savings", 100000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		account.add(accounts2);
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(
				new Customer(1, "Mora Akhila", "9999999999", "akhila@gmail.com",  account));
		customers.add(new Customer(2, "Varaganti Vaishnavi", "9646567686", "vaishnavi@gmail.com",
				 account));

		when(crepo.findAll()).thenReturn(customers);

		service.getAllCustomers().size();

		assertEquals(customers.size(), service.getAllCustomers().size());

	}

	@Test
	@Order(2)
	void test_getCustomerByCustomerId() {

		Account accounts1 = new Account(1, "Savings", 50000);
		Account accounts2 = new Account(2, "Savings", 100000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		account.add(accounts2);
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(
				new Customer(3, "Mora Akhila", "9999999999", "akhila@gmail.com", account));
		customers.add(new Customer(4, "Varaganti Vaishnavi", "9646567686", "vaishnavi@gmail.com", 
				 account));

		when(crepo.findById(anyInt())).thenReturn(Optional.of(customers.get(0)));

		assertEquals(3, service.getCustomerByCustomerId(3).getCustomerId());

	}

	@Test
	@Order(3)
	void test_getCustomerByCustomerName() {

		Account accounts1 = new Account(1, "Savings", 50000);
		Account accounts2 = new Account(2, "Savings", 100000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		account.add(accounts2);
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(
				new Customer(3, "Mora Akhila", "9999999999", "akhila@gmail.com", account));
		customers.add(new Customer(4, "Varaganti Vaishnavi", "9646567686", "vaishnavi@gmail.com",
				 account));

		String name = "Mora Akhila";

		when(crepo.findByCustomerName(name)).thenReturn(customers);

		assertEquals(customers.size(), service.getCustomerByCustomerName(name).size());

	}

	@Test
	@Order(4)
	void test_getCustomerByCustomerEmail() {

		Account accounts1 = new Account(1, "Savings", 50000);
		Account accounts2 = new Account(2, "Savings", 100000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		account.add(accounts2);
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(
				new Customer(3, "Mora Akhila", "9999999999", "akhila@gmail.com",  account));
		customers.add(new Customer(4, "Varaganti Vaishnavi", "9646567686", "vaishnavi@gmail.com",
				 account));

		String email = "vaishnavi@gmail.com";

		when(crepo.findByCustomerName(email)).thenReturn(customers);

		assertEquals(customers.size(), service.getCustomerByCustomerName(email).size());

	}

	@Test
	@Order(5)
	void test_getCustomerByCustomerPhno() {

		Account accounts1 = new Account(1, "Savings", 50000);
		Account accounts2 = new Account(2, "Savings", 100000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		account.add(accounts2);
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(
				new Customer(3, "Mora Akhila", "9999999999", "akhila@gmail.com",  account));
		customers.add(new Customer(4, "Varaganti Vaishnavi", "9646567686", "vaishnavi@gmail.com", 
				 account));

		String phoneno = "9999999999";

		when(crepo.findByCustomerName(phoneno)).thenReturn(customers);

		assertEquals(customers.size(), service.getCustomerByCustomerName(phoneno).size());

	}

	@Test
	@Order(6)
	void test_addCustomer() {

		Account accounts1 = new Account(5, "Savings", 50000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		CustomerDTO cdto = new CustomerDTO();
		Customer customers = new Customer(5, "Raji", "6307766888", "Raji@gmail.com", 
				 account);
		cdto.setCustomer(customers);

		when(crepo.save(customers)).thenReturn(customers);
		assertEquals(customers, service.addCustomer(cdto));

	}

	@Test
	@Order(7)
	void test_updateCustomer() {
		
		List<Account> acc=new ArrayList<>();
		Account account=new Account(1,"Savings",8900);
		acc.add(account);
		Customer customer = new Customer(5, "Rajeswari", "6307766888", "Raji@gmail.com",acc);
		when(crepo.findById(5)).thenReturn(Optional.of(customer));
		customer.setCustomerName("Kandikonda Sujatha");
		Customer updated = service.updateCustomer(customer);
		 
		assertThat(updated.getCustomerName()).isEqualTo("Kandikonda Sujatha");
	}

	@Test
	@Order(8)
	void test_deleteByCustomerId() {

		Account accounts1 = new Account(5, "Savings", 50000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		Customer customers = new Customer(5, "Rajeswari", "6307766888", "Raji@gmail.com", account);

		when(crepo.findById(5)).thenReturn(Optional.of(customers));

		service.deleteByCustomerId(5);

		verify(crepo, times(1)).delete(customers);
		assertEquals(0, crepo.count());
	}

	@Test
	@Order(9)
	void test_deleteAll() {

		Account accounts1 = new Account(5, "Savings", 50000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		when(crepo.findAll()).thenReturn(null);
		service.deleteAll();
		verify(crepo, times(1)).deleteAll();
		assertEquals(0, crepo.count());
	}
}
