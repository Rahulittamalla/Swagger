package me20385435.foundation.bank.ME20385435_bank.repositoryTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import me20385435.foundation.bank.ME20385435_bank.dto.AccountDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.repository.AccountRepository;
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
@DisplayName("AccountRepositoryTest")
@ActiveProfiles("test")
class RepositoryTest {

	@Autowired
	private AccountRepository arepo;
	
	Account acc = getAccountDTO().getAccount();
	 
	@BeforeEach
	public void s() { 
	 
		arepo.save(acc);
	}
	
	
	
	
	    @Test
		@Order(1)
		@DisplayName("Test: Save Account")
		void testSave() {
		  Account result = arepo.findById(acc.getAccountId()).get();
		  assertEquals(acc.getAccountId(), result.getAccountId());
		}
	 
	 
	 @Test
		@Order(2)
		@DisplayName("Test: Find Account By Id")
		void testFindById() {
		Account result = arepo.findById(acc.getAccountId()).get();
		assertEquals(acc.getAccountId(), result.getAccountId());
		}
	 
	 @Test
		@Order(3)
		@DisplayName("Test: Update Account")
		void testUpdate() {
		 Account result = arepo.findById(acc.getAccountId()).get();
		 result.setAccountId(acc.getAccountId());
		 result.setAccountType("savings");
		 result.setAccountBalance(23222);
		 		
		 
		arepo.save(result);
		 assertEquals("savings",result.getAccountType());
		}
	 
	 
	 @Test
		@Order(4)
		@DisplayName("Test: Get All Accounts")
		void testFindAll() {
		  List<Account> result = new ArrayList<Account>();
		  arepo.findAll().forEach(e -> result.add(e));
	     assertEquals(1, result.size());
		}
	 
	 
	 @Test
		@Order(5)
		@DisplayName("Test:- Delete Account By Id")
		void testDeleteById() {
		Account result = arepo.findById(acc.getAccountId()).get();
		arepo.deleteById(result.getAccountId());
		List<Account> result1 = new ArrayList<>();
		arepo.findAll().forEach(e -> result1.add(e));
		assertEquals(0, result1.size());
		}
	 
	 @Test
	 @Order(6)
	 void testFindByFieldName() {
	 List<Account> result = new ArrayList<Account>();
	 arepo.findByAccountType(acc.getAccountType()).forEach(e -> result.add(e));
	 assertEquals(1, result.size());
	}
	 
	 
	 
	 @Test
		@Order(7)
		 @DisplayName(" Test:  Delete ALL Accounts ")
		 void testDeleteAll() {
		 arepo.deleteAll();
		 List<Account> result = new ArrayList<>();
		 arepo.findAll().forEach(ac -> result.add(ac));
		 assertEquals(0, result.size());
		}
	 private AccountDTO getAccountDTO() {
			
		  AccountDTO accountDTO = new AccountDTO();
		  Account act= new Account(1,"savings",5000); 
		  
		  accountDTO.setAccount(act);
		return accountDTO;
		  
	 }   

}
