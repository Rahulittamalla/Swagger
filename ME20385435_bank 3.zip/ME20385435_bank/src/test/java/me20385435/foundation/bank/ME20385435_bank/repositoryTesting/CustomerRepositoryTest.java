package me20385435.foundation.bank.ME20385435_bank.repositoryTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import me20385435.foundation.bank.ME20385435_bank.ME20385435BankApplication;
import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.repository.CustomerRepository;


@SpringBootTest(classes = ME20385435BankApplication.class)
@TestMethodOrder(OrderAnnotation.class)
@DisplayName("CustomerRepositoryTest")
@ActiveProfiles("test")
class CustomerRepositoryTest {

	@Autowired
	private CustomerRepository customerRepository;
	Customer c = getCustomerDTO().getCustomer();

	@BeforeEach
	public void s() {

		customerRepository.save(c);
	}
	
	@Test
	@Order(1)
	@DisplayName("Test-> Save Customer")
	void testSave() {
		Customer result = customerRepository.findById(c.getCustomerId()).get();
		assertEquals(c.getCustomerId(), result.getCustomerId());
	}
	
	@Test
	@Order(2)
	@DisplayName("Test-> Find Customer By Id")
	void testFindById() {
		Customer result = customerRepository.findById(c.getCustomerId()).get();
		assertEquals(c.getCustomerId(), result.getCustomerId());
	}
	
	
	
	@Test
	@Order(3)
	@DisplayName("Test-> Update Customer")
	void testUpdate() {
		Customer result = customerRepository.findById(c.getCustomerId()).get();
		result.setCustomerId(c.getCustomerId());
		result.setCustomerName("Malli");
		result.setCustomerPhno(c.getCustomerPhno());
		result.setCustomerEmail(c.getCustomerEmail());
		result.setAccount(c.getAccount());
		customerRepository.save(result);
		assertEquals("Malli",result.getCustomerName());
	}
	@Test
	@Order(4)
	@DisplayName("Test-> Get All Customers")
	void testFindAll() {
		List<Customer> result = new ArrayList<Customer>();
		customerRepository.findAll().forEach(e -> result.add(e));
		assertEquals(1, result.size());
	}

	

	

	@Test
	@Order(5)
	@DisplayName("Test-> Delete Customer By Id")
	void testDeleteById() {
		Customer result = customerRepository.findById(c.getCustomerId()).get();
		customerRepository.deleteById(result.getCustomerId());
		List<Customer> result1 = new ArrayList<>();
		customerRepository.findAll().forEach(e -> result1.add(e));
		assertEquals(0, result1.size());
	}
	@Test
	@Order(6)
	@DisplayName("Test-> Get Customers By Using Field Name")
	void testFindByFieldName() {
		List<Customer> result = new ArrayList<Customer>();
		customerRepository.findByCustomerName(c.getCustomerName()).forEach(e -> result.add(e));
		assertEquals(1, result.size());
	}
	
	@Test
	@Order(7)
	@DisplayName("Test-> Delete ALL Customers ")
	void testDeleteAll() {
		customerRepository.deleteAll();
		List<Customer> result = new ArrayList<>();
		customerRepository.findAll().forEach(e -> result.add(e));
		assertEquals(0, result.size());
	}
	
	
	@Test
	@Order(8)
	@DisplayName("Test-> Get Customers By Using Field AccountType")
	void testFindByField() {
		List<Customer> result = new ArrayList<Customer>();
		customerRepository.findByAccountType("savings").forEach(e -> result.add(e));
		assertEquals(1, result.size());
	}
	
	private CustomerDTO getCustomerDTO() {
		CustomerDTO customerDTO = new CustomerDTO();
		List<Account> accountList = new ArrayList<Account>();
		Account a = new Account();
		a.setAccountId(1);
		a.setAccountType("savings");
		a.setAccountBalance(8000);
		accountList.add(a);
		Customer c = new Customer();
		c.setCustomerId(1);
		c.setCustomerName("Raji");
		c.setCustomerPhno("9090909090");
		c.setCustomerEmail("Raji@gmail.com");
		c.setAccount(accountList);
		customerDTO.setCustomer(c);
		return customerDTO;
	}


}
