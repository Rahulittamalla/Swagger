package me20385435.foundation.bank.ME20385435_bank.serviceTesting;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;


import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.repository.AccountRepository;
import me20385435.foundation.bank.ME20385435_bank.service.AccountService;
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest
class AccountServiceTests {

	
	@InjectMocks
	private AccountService accountService;
	
	@Mock
	private AccountRepository accountRepository;
	
	 
	
	
	
	@Test
	void test_getAllAccounts() {
		Account accounts1 = new Account(1, "Savings", 50000);
		Account accounts2 = new Account(2, "current", 100000);
		List<Account> accounts=new ArrayList<>();
		accounts.add(accounts2);
		accounts.add(accounts1);
		when(accountRepository.findAll()).thenReturn(accounts);

		int size=accountService.getAllAccounts().size();

		assertEquals(accounts.size(),size);	
	}

	@Test
	void test_getAccountByAccountId() {

		Account account = new Account(1, "Savings", 50000);
		when(accountRepository.findById(anyInt())).thenReturn(Optional.of(account));
		assertEquals(1, accountService.getAccountByAccountId(1).getAccountId());

	}
	
	@Test
	void test_getAccountByAccountType() {

		Account accounts1 = new Account(1, "Savings", 50000);
		List<Account> account = new ArrayList<>();
		account.add(accounts1);
		
		when(accountRepository.findByAccountType(accounts1.getAccountType())).thenReturn(account);

		assertEquals(1, accountService.getByAccountType(accounts1.getAccountType()).size());

	}
	@Test
	void test_deleteByAccountId() {

		Account account = new Account(1, "Savings", 50000);
		
		when(accountRepository.findById(anyInt())).thenReturn(Optional.of(account));

		accountService.deleteAccountById(1);

		verify(accountRepository, times(1)).delete(account);
		assertEquals(0, accountRepository.count());

	}
	
	@Test
    void test_MoneyTransfer() {
		Account account1 = new Account(1, "Savings", 59000);
		Account account2 = new Account(2, "current", 13000);
		when(accountRepository.findById(1)).thenReturn(Optional.of(account1));
		when(accountRepository.findById(2)).thenReturn(Optional.of(account2));
		accountService.moneyTransfer(account1.getAccountId(), account2.getAccountId(), 5000);
		assertEquals(18000, account2.getAccountBalance());
		assertEquals(54000, account1.getAccountBalance());
		
	}
	@Test
	@DisplayName("Test : Delete All Customers")
	void test_deleteAllAccounts() {
	when(accountRepository.findAll()).thenReturn(null);
	accountService.deleteAll();
	verify(accountRepository,times(1)).deleteAll();
	assertEquals(0,accountRepository.count());

	}
	
	
	
}
