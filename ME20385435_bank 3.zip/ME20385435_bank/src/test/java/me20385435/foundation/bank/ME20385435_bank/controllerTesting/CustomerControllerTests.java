package me20385435.foundation.bank.ME20385435_bank.controllerTesting;




import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import me20385435.foundation.bank.ME20385435_bank.controller.CustomerController;
import me20385435.foundation.bank.ME20385435_bank.dto.CustomerDTO;
import me20385435.foundation.bank.ME20385435_bank.model.Account;
import me20385435.foundation.bank.ME20385435_bank.model.Customer;
import me20385435.foundation.bank.ME20385435_bank.service.CustomerService;


@WebMvcTest(value=CustomerController.class)
class CustomerControllerTests {

	
	@MockBean
	private  CustomerService customerService;
	
	
	@Autowired
	private MockMvc mockMvc;

	
	@Autowired
	private ObjectMapper objectMapper;
	
	
	private Customer customer;
	private Account accounts;
	
	@BeforeEach
	void init(){
		 accounts = new Account(1, "Savings", 50000);
		List<Account> account = new ArrayList<>();
		account.add(accounts);
	    customer = new Customer(1, "Raji", "9999999999", "Raji@gmail.com", account);
		
	}
	
	
	
	@Test
	void getAllCustomers() throws Exception {
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(customer);
		when(customerService.getAllCustomers()).thenReturn(customers);
		this.mockMvc.perform(get("/bank/getAllCustomers"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.size()",is(customers.size())));

	}

	@Test
	void test_AddCustomer() throws Exception {
		CustomerDTO cdto = new CustomerDTO();
		cdto.setCustomer(customer);

		when(customerService.addCustomer(any(CustomerDTO.class))).thenReturn(cdto.getCustomer());

		this.mockMvc.perform(post("/bank/add").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(cdto))).andExpect(status().isCreated());

	}
	
	@Test
	void test_getCustomerById() throws Exception {
		
		when(customerService.getCustomerByCustomerId(anyInt())).thenReturn(customer);
		this.mockMvc.perform(get("/bank/CustomerId/{id}",1)).andExpect(status().isOk());
				
		
	}
	
	
	@Test
	void test_getCustomerByName() throws Exception {
		
		when(customerService.getCustomerByCustomerId(anyInt())).thenReturn(customer);
		this.mockMvc.perform(get("/bank/CustomerName/{name}","Raji"))
		.andExpect(status().isOk());				
		
		
	}
	
	@Test
	void test_getCustomerByNameAndPhno() throws Exception {
		when(customerService.getCustomerByCustomerNameAndCustomerPhno(customer.getCustomerName(), customer.getCustomerPhno())).thenReturn(customer);
		this.mockMvc.perform(get("/bank/CustomerName/{name}/CustomerPhno/{phno}",customer.getCustomerName(), customer.getCustomerPhno()))
		.andExpect(status().isOk());				
		
		
	}
	
	@Test
	void test_getCustomerByNameAndPhnoAndAccountType() throws Exception {
		when(customerService.getCustomerByCustomerNameAndAccountTypeAndCustomerPhno(customer.getCustomerName(), customer.getCustomerPhno(),"Savings")).thenReturn(customer);
		this.mockMvc.perform(get("/bank/CustomerName/{name}/CustomerPhno/{phno}/accountType/{accountType}",customer.getCustomerName(), customer.getCustomerPhno(),"Savings"))
		.andExpect(status().isOk());				
		
	}
	
	
	
	
	
	@Test
	void test_deleteCustomerById() throws Exception {
		
		doNothing().when(customerService).deleteByCustomerId(anyInt());
		this.mockMvc.perform(delete("/bank/delete/{id}",1))
		.andExpect(status().isAccepted());				
		
		
	}
	@Test
	void test_deleteCustomers() throws Exception {
		
		doNothing().when(customerService).deleteAll();
		this.mockMvc.perform(delete("/bank/delete/"))
		.andExpect(status().isAccepted());				
		
		
	}
	
	@Test
	void test_updateCustomer() throws Exception {
		when(customerService.updateCustomer(any(Customer.class))).thenReturn(customer);
		this.mockMvc.perform(put("/bank/updateCustomer")
		.contentType(MediaType.APPLICATION_JSON)
		.content(objectMapper.writeValueAsString(customer)))
		.andExpect(status().isCreated());	
	}
	
	
	
	
	
	
	
	
}
