package avitepa.foundation.bank.AVITEPA_bank;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import avitepa.foundation.bank.AVITEPA_bank.exception.CustomerNotFoundException;
import avitepa.foundation.bank.AVITEPA_bank.exception.DuplicateCustomerException;
import avitepa.foundation.bank.AVITEPA_bank.exception.DuplicationAccountTypeException;
import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.repo.AccountRepo;
import avitepa.foundation.bank.AVITEPA_bank.repo.CustomerRepo;
import avitepa.foundation.bank.AVITEPA_bank.service.CustomerService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class CusttomerServiceTest {
	
	@Mock
	private CustomerRepo customerRepo;
	
	@Mock
	private AccountRepo accountRepo;
	
	@InjectMocks
	private CustomerService customerService;
	
	@Test
	public void testCreateCustomer() throws DuplicateCustomerException
	{
		
       Customer customer= new Customer();
       
       customer.setCustomerId(1L);
       customer.setCustomerName("rahul");
       customer.setEmail("rahul@example.com");
       
       List<Account> accounts= new ArrayList<>();
       
       Account account1 =new Account();
		account1.setAccountId(1L);
		account1.setAccountType("Savings");
		account1.setBalance(10000);
		accounts.add(account1);
		account1.setCustomer(customer);
		
		customer.setAccounts(accounts);
		
		if(customer.getAccounts() != null)
		{
			customer.getAccounts().forEach(account->account.setCustomer(customer));
		}
		
		
	
		//when(customerRepo.findByEmail(customer.getEmail())).thenReturn(Optional.empty());
		when(customerService.addCustomer(customer)).thenReturn(customer);
		
		//Act
		Customer result=customerService.addCustomer(customer);
		
		//Assert
		
		verify(customerRepo,times(2)).findByEmail(customer.getEmail());
		verify(customerRepo,times(1)).save(customer);
		//verify(accountRepo,times(1)).save(any(Account.class));

		assertEquals(customer,result);
		
	}
	
	@Test
	void testCreateCustomer_throwDuplicationExcetpion() throws DuplicateCustomerException
	{
		Customer customer= new Customer();
		
		customer.setCustomerName("Rahul");
		customer.setEmail("rahul@example.com");
		
		when(customerRepo.findByEmail(customer.getEmail())).thenReturn(Optional.of(customer));
		
		assertThrows(DuplicateCustomerException.class, () -> customerService.addCustomer(customer));
	}
	
	@Test
	public void testAddAccountToCustomer()
	{
		Long customerId=1L;
		
		Customer customer= new Customer();
		
		customer.setCustomerId(customerId);
		
	
		
		Account account1= new Account();
		
		account1.setAccountId(1L);
		account1.setAccountType("current");
		account1.setBalance(12345);
		customer.setAccounts(Collections.singletonList(account1));
		
	//set up mock behaviour for customerRepo.findById()
	
	when(customerRepo.findById(customerId)).thenReturn(Optional.of(customer));
	
	//set up mock behaviour accountRepo.save()
	
	//when(accountRepo.save(Mockito.any(Account.class))).thenReturn(account1);
	
	//create a service instance and  call the method being tested
	
	Account newAccount= new Account();
	
	newAccount.setAccountId(2L);
	newAccount.setBalance(23456);
	newAccount.setAccountType("savings");
	
	when(accountRepo.save(Mockito.any(Account.class))).thenReturn(newAccount);

	customerService.addAccountToCustomer(customerId, newAccount);
	
	//verify that the customerRepo.findById exactly once
	
	verify(customerRepo,times(1)).findById(customerId);
	
	verify(accountRepo,times(1)).save(newAccount);

//	assertDoesNotThrow(()->customerService.addAccountToCustomer(customerId, newAccount));
//	
//	
//		
//	//Verify that the accountRepo.save method was called once with the new account
//	verify(accountRepo,times(1)).save(newAccount);
//	
//	verify(customerService).addAccountToCustomer(customerId, newAccount);
//	
//	assertEquals(3,customer.getAccounts().size());
//	
//	assertTrue(customer.getAccounts().contains(newAccount));
//	
//	Account duplicateAccount= new Account();
//	
//	duplicateAccount.setAccountType("Savings");
//	duplicateAccount.setBalance(5000.00);
//	
//	assertThrows(DuplicationAccountTypeException.class, ()-> {customerService.addAccountToCustomer(customerId, newAccount);
//	
//	
//	});
//	
	}
	
	@Test
	public void testUpdateTheCustomerDetails()
	{
		//Create a customer to update
		
		Customer customerToUpdate= new Customer();
		customerToUpdate.setCustomerId(1L);
		customerToUpdate.setCustomerName("dummy");
		customerToUpdate.setEmail("dummy@Example.com");
		List<Account> accounts=new ArrayList<>();
		
		Account account= new Account();
		account.setAccountId(1L);
		account.setAccountType("savings");
		account.setBalance(10000);
		accounts.add(account);
		
		customerToUpdate.setAccounts(accounts);
		
		when(customerRepo.save(customerToUpdate)).thenReturn(customerToUpdate);
		
		//specify the behaviour of the mock customer repository
		
		
		
		// create mock found customer with some existing details
		
		Customer updatedCustomer= new Customer();
		
		//updatedCustomer.setCustomerId(1L);
		updatedCustomer.setCustomerName("Rahul");
		updatedCustomer.setEmail("rahul@Example.com");
		
		when(customerRepo.findById(1L)).thenReturn(Optional.of(customerToUpdate));

		//call the method being tested
		
		Customer result= customerService.updateTheCustomerDetails(1L, updatedCustomer);
		
		//verify that the save method was called on the customer repository
		
		//verify(customerRepo,times(2)).save(updatedCustomer);
		
		//assert that the returned customer has the expected details
		
		assertEquals("Rahul", result.getCustomerName());
		assertEquals("rahul@Example.com",result.getEmail());
	
	}

	@Test
	public void testDeleteCustomer() throws CustomerNotFoundException
	{
		//Arange
		
		Long customerId=1L;
		
		Customer customer= new Customer();
		
		customer.setCustomerId(customerId);
		
		when(customerRepo.findById(customerId)).thenReturn(Optional.of(customer));
		
		//assertDoesNotThrow(() -> customerService.deleteCustomer(1));
		
		//Act
		
		customerService.deleteCustomer(customerId);
		
		//Assert
		
		verify(customerRepo,times(1)).findById(customerId);
		verify(customerRepo,times(1)).delete(customer);
		
	}
	@Test
	public void deleteCustomer_throwsCustomerNotFoundException() throws CustomerNotFoundException
	{
		//Arrange
		
		long customerId=1L;
		
		when(customerRepo.findById(customerId)).thenReturn(Optional.empty());
		
		//Act&Assert
		
		assertThrows(CustomerNotFoundException.class, () -> customerService.deleteCustomer(customerId));
		
	}
	
	@Test
	public void testGetAllCustomers()
	{
		List<Customer> customers= new ArrayList<>();
		
		when(customerService.getAllCustomer()).thenReturn(customers);
		
		verify(customerRepo, times(1)).findAll();
	}
	


}
