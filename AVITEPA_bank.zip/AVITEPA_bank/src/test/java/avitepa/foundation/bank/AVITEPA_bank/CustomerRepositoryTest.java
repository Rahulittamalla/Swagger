package avitepa.foundation.bank.AVITEPA_bank;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.repo.CustomerRepo;


@ExtendWith(MockitoExtension.class)
@SpringBootTest
class CustomerRepositoryTest {

	@Mock
	private CustomerRepo customerRepo;
			
	@Test
	public void testGetAllCustomers()
	{
		List<Customer> customers= new ArrayList<>();
		
		
		Customer customer1 =new Customer();
		
		customer1.setCustomerId(1L);
		customer1.setCustomerName("Mark");
		customer1.setEmail("mark@example.com");
		Account account1 =new Account();
		account1.setAccountId(1L);
		account1.setAccountType("Savings");
		account1.setBalance(10000);
		account1.setCustomer(customer1);
		//customer1.setAccounts(Collections.singletonList(account1));
		
Customer customer2 =new Customer();
		
		customer2.setCustomerId(1L);
		customer2.setCustomerName("drStrange");
		customer2.setEmail("strange@example.com");
		Account account2=new Account();
		account2.setAccountId(1L);
		account2.setAccountType("Savings");
		account2.setBalance(10000);
		account2.setCustomer(customer2);
		
		
		customers.add(customer1);
		customers.add(customer2);

		when(customerRepo.findAll()).thenReturn(customers);
		
		List<Customer> results=customerRepo.findAll();
		
		assertEquals(2,results.size());
		
		Customer resultCustomer1= results.get(0);
		assertEquals("Mark",resultCustomer1.getCustomerName());
		assertEquals("mark@example.com",resultCustomer1.getEmail());
		
		Customer resultCustomer2=results.get(1);
		
		assertEquals("drStrange",resultCustomer2.getCustomerName());
		assertEquals("strange@example.com",resultCustomer2.getEmail());
		
	}

	 
	@Test
	public void testCreateCustomer()
	{
	
        Customer customer =new Customer();
		customer.setCustomerId(1L);
		customer.setCustomerName("Mark");
		customer.setEmail("mark@example.com");
		Account account1 =new Account();
		account1.setAccountId(1L);
		account1.setAccountType("Savings");
		account1.setBalance(10000);
		account1.setCustomer(customer);
		//customer1.setAccounts(Collections.singletonList(account1));
		
		when(customerRepo.save(customer)).thenReturn(customer);

		
		Customer savedCustomer= customerRepo.save(customer);
		assertNotNull(savedCustomer.getCustomerId());
				
        assertEquals("Mark",savedCustomer.getCustomerName());
	}
	
	@Test
	public void testGetCustomerById()
	{
		Long customerId=1L;
		
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setCustomerName("Rahul");
		customer.setEmail("rahul@example.com");
		when(customerRepo.findById(customerId)).thenReturn(Optional.of(customer));
		
		Optional<Customer> result= customerRepo.findById(customerId);
		assertTrue(result.isPresent());
		
		assertEquals(customerId, result.get().getCustomerId());
		assertEquals("Rahul",result.get().getCustomerName());
		assertEquals("rahul@example.com",result.get().getEmail());
		
	}
	
	@Test
	public void testDeleteCustomer()
	{
		
		Long customerId=1L;
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setCustomerName("Rahul");
		customer.setEmail("rahul@exmaple.com");
		
		//mock the findById() method to return the customer object
		
		when(customerRepo.findById(customerId)).thenReturn(Optional.of(customer));
		
		//print out the customer object before calling delete() method
		
		System.out.println("customerId"+customer);
		
		
		doNothing().when(customerRepo).delete(customer);
//		
//		customerRepo.delete(customer);
		
		verify(customerRepo,times(1)).findById(customerId);
		verify(customerRepo, times(1)).delete(customer);;
		
	}
}
