package avitepa.foundation.bank.AVITEPA_bank.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class AccountNotFoundException extends RuntimeException {
	
//	public AccountNotFoundException(Long customerId,String accountType)
//	{
//		super("could not found find account of type "+accountType+"for customer"+customerId);
//	}
	
	public AccountNotFoundException(Long accountId)
	{
		super("could not found find account of type "+accountId);
	}


}


