package avitepa.foundation.bank.AVITEPA_bank.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonProperty;

import avitepa.foundation.bank.AVITEPA_bank.service.AccountService;
import lombok.Data;



@Entity
@Data
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonProperty
	private Long customerId;
	
	@JsonProperty
	private String customerName;
	
	@JsonProperty
	private String email;
	
	//private String address,phone number;
	
	@JsonProperty
    @OneToMany(mappedBy="customer",cascade=CascadeType.ALL,orphanRemoval=true)
	private List<Account> accounts;

	

}
