package avitepa.foundation.bank.AVITEPA_bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import avitepa.foundation.bank.AVITEPA_bank.exception.AccountNotFoundException;
import avitepa.foundation.bank.AVITEPA_bank.exception.InsufficientFundsException;
import avitepa.foundation.bank.AVITEPA_bank.model.Account;
import avitepa.foundation.bank.AVITEPA_bank.model.Customer;
import avitepa.foundation.bank.AVITEPA_bank.repo.AccountRepo;

@Service
public class AccountService {
	
	@Autowired
	private AccountRepo accountRepo;
	
	public Account createAccount(Account account)
	{
	
		return accountRepo.save(account);
	}

	public void deleteAccount(Long accountid) throws AccountNotFoundException
	{
		Account existingAccount= accountRepo.findById(accountid).orElseThrow(()-> new AccountNotFoundException(accountid));
		
		
		
		accountRepo.deleteById(existingAccount.getAccountId());
	}
	
	public List<Account> getAllAccounts() throws InsufficientFundsException
	{
		return accountRepo.findAll();
	}
	
	public Account getAccountById(Long id) throws AccountNotFoundException
	{
		return accountRepo.findById(id).orElseThrow( );
	}
	
	 
}
