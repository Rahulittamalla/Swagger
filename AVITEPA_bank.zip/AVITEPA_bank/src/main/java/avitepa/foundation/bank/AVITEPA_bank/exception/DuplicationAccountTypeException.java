package avitepa.foundation.bank.AVITEPA_bank.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class DuplicationAccountTypeException extends RuntimeException {
	
    public DuplicationAccountTypeException(String accountType) {
    	super("Customer already has an account of type "+accountType);
    }
}
