package avitepa.foundation.bank.AVITEPA_bank.controller;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.context.ShutdownEndpoint;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.actuate.info.InfoEndpoint;
import org.springframework.boot.actuate.logging.LogFileWebEndpoint;
import org.springframework.boot.actuate.logging.LoggersEndpoint;
import org.springframework.boot.actuate.metrics.MetricsEndpoint;
import org.springframework.boot.actuate.trace.http.HttpTraceEndpoint;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/actuator")
public class ActuatorController {
	

	@Autowired
	private HealthEndpoint healthEndPoint;
	
	@Autowired
	private InfoEndpoint infoEndPoint;
	
//	@Autowired
//	private LoggersEndpoint loggersEndpoints;
//	
//	@Autowired
//	private HttpTraceEndpoint httpTraceEndpoint;
//	
//	@Autowired
//	private LogFileWebEndpoint logFileWebEndpoint;
//	
//	@Autowired
//	private ShutdownEndpoint shutDownEndPoint;
//	
	@Autowired
	private MetricsEndpoint metricsEndPoint;
	
	
	@GetMapping("/health")
	public ResponseEntity<String> actutorMapping()
	{
		HealthComponent health=healthEndPoint.health();
		if(health.getStatus().equals(Status.UP))
		{
			return ResponseEntity.ok("Applicaiton is up and running");
		}
		else
		{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Applicaiton is not healthy");
		}
	
	}
	
	@GetMapping("/info")
	public ResponseEntity<Object> info()
	{
		return ResponseEntity.ok().body(infoEndPoint.info());
	}
	
	@GetMapping("/logfile")
	public ResponseEntity<Object> logfile() throws IOException
	{
		
		Path logFilePath = Paths.get("logs","spring.log");
		
		String logFileContents=Files.readString(logFilePath);
		return ResponseEntity.ok().body(logFileContents);
	}
	
	@GetMapping("/metrics")
	public ResponseEntity<Object> metrics()
	{
		return ResponseEntity.ok().body(metricsEndPoint.listNames());
	}

}
