package avitepa.foundation.bank.AVITEPA_bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import avitepa.foundation.bank.AVITEPA_bank.service.AccountService;
import avitepa.foundation.bank.AVITEPA_bank.service.TransferService;

@RestController
@RequestMapping("/api")
public class AccountController {
	
	@Autowired
	private TransferService transferService;
	
	@Autowired
	private AccountService accountService;
	
	//
	@PostMapping("/transfer")
	public ResponseEntity<Void>transferFunds(@RequestParam Long sourceAccountId,@RequestParam Long targetAccountId, @RequestParam Double amount)
	{
		
		transferService.transferFunds(sourceAccountId, targetAccountId, amount);
		
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
	@DeleteMapping("/acc/delete/{accountId}")
	public ResponseEntity<Void> deleteAccountById(@PathVariable Long accountId)
	{
		accountService.deleteAccount(accountId);
	 return ResponseEntity.noContent().build();
	}

}
